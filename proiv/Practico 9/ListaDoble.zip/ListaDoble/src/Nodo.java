public class Nodo <E>{
    public Object dato;
    public Nodo<Object> siguiente;
    public Nodo<Object> anterior;

    public Nodo(Object e) {
        this.dato = e;
    }


    public String Nodo(Object dato) {
        return dato.toString();
    }


    public Object getDato() {
        return this.dato;
    }

    public void setDato(Object dato) {
        this.dato = dato;
    }


    public Nodo<Object> getSiguiente() {
        return siguiente;
    }


    public Nodo<Object> getAnterior() {
        return anterior;
    }


    public void setAnterior(Nodo<Object> anterior) {
        this.anterior = anterior;
    }

    public void setSiguiente(Nodo<Object> siguiente) {
        this.siguiente = siguiente;
    }
}
