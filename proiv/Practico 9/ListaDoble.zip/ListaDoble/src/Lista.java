public class Lista<E> {
    private Nodo<Object> inicio;
    private Nodo<Object> fin;

    // El constructor de la clase.
    public Lista() {
        inicio = null;
        fin = null;
    }

    public void insertar(Object e) {
        Nodo<Object> nuevo = new Nodo<>(e);
        if (inicio == null) {
            inicio = nuevo;
            fin = nuevo;
        } else {
            fin.setSiguiente(nuevo);
            fin = nuevo;
        }
    }

    public Object get(int posicion) {
        Nodo<Object> actual = inicio;
        int i = 0;
        while (actual != null) {
            if (i == posicion) {
                return actual.getDato();
            }
            actual = actual.getSiguiente();
            i++;
        }
        return null;
    }

    public void eliminar(int posicion) {
        Nodo<Object> actual = inicio;
        Nodo<Object> anterior = null;
        int i = 0;
        while (actual != null) {
            if (i == posicion) {
                if (anterior == null) {
                    inicio = actual.getSiguiente();
                } else {
                    anterior.setSiguiente(actual.getSiguiente());
                }
                return;
            }
            anterior = actual;
            actual = actual.getSiguiente();
            i++;
        }
    }


    public String toString() {
        String str = "";
        Nodo<Object> actual = inicio;
        while (actual != null) {
            str += actual.getDato() + " ";
            actual = actual.getSiguiente();
        }
        return str;
    }

}